
<?php
require_once 'connect.php';
print_r($_POST);
if(isset($_POST['action'])){
    // $id = $_POST['id'] ?? "";?
if ($_POST['action'] == 'Add Book') {
    echo "Add Book";
    $title = $_POST['title'];
    $author = $_POST['author'];
    $price = $_POST['price'];
    $available = $_POST['available'];
    $pages = $_POST['pages'];
    echo $title . $author . $price . $available . $pages;
    if (empty($title) || empty($author) || empty($price) || empty($available) || empty($pages)) {
        echo "Error: All fields are required.";
        return;
      }
      $sql = "INSERT INTO books (title, author, price, available, pages) VALUES ('$title', '$author', '$price', '$available', '$pages')";
      $pdo->exec($sql);

   
    
} else if ($_POST['action'] == 'Edit Book') {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $author = $_POST['author'];
    $price = $_POST['price'];
    $available = $_POST['available'];
    $pages = $_POST['pages'];
    $sql = "UPDATE books SET title='$title', author='$author', price='$price', available='$available', pages='$pages' WHERE ID=$id";
    $pdo->exec($sql);
    
}else if($_POST['action'] == 'Delete Book'){
    $id = $_POST['id'];
    $sql = "DELETE FROM books WHERE ID=$id";
    $pdo->exec($sql);
}
}


