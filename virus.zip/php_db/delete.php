<?php $id = $_GET['id'] ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="crud_books.php" method="POST">
        <p>Do you really want to delete this book <?php echo$id ?>?</p>
        <input type="hidden" name="id" value="<?php echo$id ?>">
        <input type="submit" name="action" value="Delete Book">
    </form>
    
</body>
</html>