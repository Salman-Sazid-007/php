<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="crud_books.php" method="POST">
        <input type="hidden" name="id" value="<?php echo$_GET['id'] ?>">
        <input type="text" name="title" placeholder="Title" value="<?php echo$_GET['title'] ?>"> <br>
        <input type="text" name="author" placeholder="Author" value="<?php echo$_GET['author'] ?>" > <br>
        <input type="text" name="price" placeholder="Price" value="<?php echo$_GET['price'] ?>" > <br>
        <input type="text" name="available" placeholder="Available" value="<?php echo$_GET['available'] ?>"> <br>
        <input type="text" name="pages" placeholder="Pages" value="<?php echo$_GET['pages'] ?>" > <br>
        <input type="submit" name="action" value="Edit Book">
    </form>
    
</body>
</html>