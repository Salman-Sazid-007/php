<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }
        td,th {
            padding: 5px;
            text-align: center;
        }
        body{
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
    </style>
</head>
<body>
    <h2>BOOKS</h2>
    
<?php 
    require_once 'connect.php';
    $stmt = $pdo->query('SELECT * FROM books');
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
   
    if(count($rows) > 0){
        echo '<table>';
        echo '<tr><th>ID</th><th>Title</th><th>Author</th><th>Price</th><th>Available</th><th>Pages</th><th>Actions</th></tr>';

        foreach ($rows as $row) {
            echo '<tr>';
            echo '<td>' . $row['ID'] . '</td>';
            echo '<td>' . $row['TITLE'] . '</td>';
            echo '<td>' . $row['AUTHOR'] . '</td>';
            echo '<td>' . $row['PRICE'] . '</td>';
            echo '<td>' . $row['AVAILABLE'] . '</td>';
            echo '<td>' . $row['PAGES'] . '</td>';

            echo '<td><a href="edit.php?id=' . $row['ID'].'&title=' . $row['TITLE'] ."&author=" . $row['AUTHOR'] . "&price=" . $row['PRICE'] . "&available=" . $row['AVAILABLE'] . "&pages=" . $row['PAGES'] . '">Edit</a> | <a href="delete.php?id=' . $row['ID'] . '">Delete</a></td>';
        

            echo '</tr>';
        }

        echo '</table>';
    }else{
        echo 'No books found';
    }

 ?>

</table>
<br>
<br>
<br>
<br>
<br>
<br>
<form action="crud_books.php" method="POST">
        <input type="text" name="title" placeholder="Title" value="muyeed"> <br>
        <input type="text" name="author" placeholder="Author" value="muyeed"> <br>
        <input type="text" name="price" placeholder="Price" value="99.99"> <br>
        <input type="text" name="available" placeholder="Available" value="1"> <br>
        <input type="text" name="pages" placeholder="Pages" value="100"> <br>
        <input type="submit"name="action" value="Add Book">
    </form>

    
    </body>
    </html>